#include "EnemyBase.h"
#include "Field.h"
#include "Player.h"

EnemyBase::EnemyBase()
{
}

EnemyBase::~EnemyBase()
{
}
